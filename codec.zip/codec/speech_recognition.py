import speech_recognition as sr
import tkinter as tk
from tkinter import filedialog, messagebox

# Create recognizer
r = sr.Recognizer()

# Function: Microphone speech to text
def record_speech():
    try:
        with sr.Microphone() as source:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, "Listening...\n")
            audio = r.listen(source)

        text = r.recognize_google(audio)
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, text)

    except sr.UnknownValueError:
        messagebox.showerror("Error", "Could not understand audio")

    except sr.RequestError:
        messagebox.showerror("Error", "Speech service error")


# Function: Audio file to text
def convert_audio():
    file_path = filedialog.askopenfilename(filetypes=[("WAV files", "*.wav")])

    if file_path:
        with sr.AudioFile(file_path) as source:
            audio = r.record(source)

        try:
            text = r.recognize_google(audio)
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, text)

        except sr.UnknownValueError:
            messagebox.showerror("Error", "Audio not clear")


# Function: Save text
def save_text():
    text = result_text.get(1.0, tk.END)

    file = filedialog.asksaveasfile(defaultextension=".txt",
                                    filetypes=[("Text files", "*.txt")])

    if file:
        file.write(text)
        file.close()
        messagebox.showinfo("Saved", "Transcription saved successfully")


# GUI Window
window = tk.Tk()
window.title("Speech to Text Transcription Tool")
window.geometry("500x400")

title = tk.Label(window, text="Speech to Text Tool", font=("Arial", 16))
title.pack(pady=10)

# Buttons
mic_button = tk.Button(window, text="Record Speech", command=record_speech)
mic_button.pack(pady=5)

audio_button = tk.Button(window, text="Upload Audio File", command=convert_audio)
audio_button.pack(pady=5)

save_button = tk.Button(window, text="Save Text", command=save_text)
save_button.pack(pady=5)

# Text box
result_text = tk.Text(window, height=12, width=50)
result_text.pack(pady=10)

window.mainloop()